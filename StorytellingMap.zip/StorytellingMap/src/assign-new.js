const assignNew=(...args)=>Object.assign({},...args)
export default assignNew
